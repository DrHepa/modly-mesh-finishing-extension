# CuMesh core-only source profile

This is an explicit adaptation of visualbruno/CuMesh at
`d10e54c30ddd03d11472c1431693f985501c7966`, not an unmodified upstream wheel.
It exposes `CuMesh` and `Atlas` only. The own native core and required xatlas
extension remain; BVH, Python remeshing, native DC bindings and their sources
are absent. `cumesh.remeshing` and `cumesh.bvh` are intentionally unavailable.
No replacement or fake DC API is supplied.

This experimental topology2 variant adds independently implemented interior-edge
link-condition, closed-one-ring ownership and indexed boundary-collar guards. Native patch SHA256:
`312cfb4fa9b2b4f69aa5b0b55aaf4f1d4e2375359b92a32f281fb48d19dfbddd`.
It remains geometry-only:
it does not transfer UV/PBR, guarantee error caps, or prove visual quality.
Preserve applicable upstream notices in `LICENSE` and `CORE_ONLY_NOTICES.txt`.
Third-party/toolchain license scope still requires admission; this profile is
not a blanket commercial-clearance claim.

Build only after separate authorization and exact diff/license review, using
pinned Torch/CUDA/compiler identities and isolated external build outputs.
A built wheel alone does not establish native, kernel or platform qualification.
