# CuMesh topology2 corresponding source

The 29 files under `source/` are the exact compiled source profile of
visualbruno/CuMesh revision `d10e54c30ddd03d11472c1431693f985501c7966`,
with the core-only module selection and topology2 simplify changes by
DrHepa. `SOURCE_SHA256` lists their hashes. Keep the accompanying upstream
CuMesh, xatlas and compiled-header notices. No cuBVH source or executable,
CUDA toolkit, Python environment, dependencies, or build logs are included.

On Linux ARM64, use a local CUDA 13.0 SDK (including CCCL headers), GCC 13.3,
Ninja 1.11, and a separate CPython 3.12.16 environment with PyTorch
2.12.0+cu130, pip 26.3, and setuptools 81.0.0. Obtain those dependencies
under their own terms. For the build below, choose physical directories
with no whitespace and set `CUMESH_BUILD_PYTHON` (the environment's Python)
and `CUDA_HOME` before starting. If Python and Torch do not share a
single parent installation directory, add each distinct real include root
to both prefix-map variables.

```sh
cd source
SRC=$(pwd -P)
ABI=$("$CUMESH_BUILD_PYTHON" -I -B -c 'from pathlib import Path; import sys; print(Path(sys.prefix).resolve().parent)')
export BUILD_TARGET=cuda TORCH_CUDA_ARCH_LIST=12.1+PTX
export CUDA_INC_PATH="$CUDA_HOME/include/cccl"
export PATH="$CUDA_HOME/bin:$PATH" CC=gcc CXX=g++ MAX_JOBS=8
export CFLAGS="-ffile-prefix-map=$SRC=/usr/src/cumesh-topology2 -ffile-prefix-map=$ABI=/usr/src/cumesh-abi"
export CXXFLAGS="$CFLAGS"
export NVCC_APPEND_FLAGS="-Xcompiler=-ffile-prefix-map=$SRC=/usr/src/cumesh-topology2 -Xcompiler=-ffile-prefix-map=$ABI=/usr/src/cumesh-abi"
CUDA_VISIBLE_DEVICES= "$CUMESH_BUILD_PYTHON" -I -B -m pip wheel --no-build-isolation --no-deps --no-index --no-cache-dir . --wheel-dir ../wheel
```

Build outside an installed extension and inspect both ELF members for
private paths before distributing. A rebuild intentionally makes no
bit-identical, portability, or redistribution claim. The runtime accepts
only the pinned release artifact. For a different binary, update its
wheel/native hashes, preserve notices, and requalify the optional runtime
in isolation instead of bypassing the lock.
