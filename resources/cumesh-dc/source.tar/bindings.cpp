// CuMesh MIT subset, Jianfeng XIANG 2025; see LICENSE. Isolated DC proof.
#include <torch/extension.h>
#include "src/hash/api.h"
#include "src/remesh/api.h"
std::tuple<torch::Tensor,torch::Tensor,torch::Tensor,torch::Tensor,torch::Tensor> contour_dual_contour(const torch::Tensor&,const torch::Tensor&,const torch::Tensor&,const torch::Tensor&,int,int,int);
PYBIND11_MODULE(TORCH_EXTENSION_NAME,m) {
 m.def("hashmap_insert_3d_idx_as_val_cuda", &cumesh::hashmap_insert_3d_idx_as_val_cuda);
 m.def("hashmap_lookup_3d_cuda", &cumesh::hashmap_lookup_3d_cuda);
 m.def("get_sparse_voxel_grid_active_vertices", &cumesh::get_sparse_voxel_grid_active_vertices);
 m.def("contour_dual_contour", &contour_dual_contour);
}
