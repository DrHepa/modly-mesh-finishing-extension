# SPDX-License-Identifier: GPL-3.0-or-later
"""Owned CuMesh CUDA contours with a separate CPU Blender BVH distance provider."""
import argparse,ctypes,hashlib,importlib.util,json,os,signal,sys,tempfile,time
from pathlib import Path
MAX_VERTICES=2_000_000
MAX_FACES=2_000_000
MAX_OUTPUT_FACES=1_250_000
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def read_obj(path,deadline):
    import numpy as np
    path=Path(path)
    if not path.is_absolute()or not path.is_file()or path.is_symlink()or path.stat().st_size>512*1024**2:raise ValueError('Invalid bounded staged OBJ input')
    vertices=[];faces=[]
    with path.open('r',encoding='ascii')as stream:
        for number,line in enumerate(stream):
            if number>4_000_100 or len(line)>4096:raise ValueError('OBJ line/work admission exceeded')
            if number%4096==0 and time.monotonic()>=deadline:raise TimeoutError('OBJ parse deadline')
            tokens=line.split()
            if not tokens or tokens[0].startswith('#'):continue
            if tokens[0]=='v'and len(tokens)==4:
                vertices.append([float(x)for x in tokens[1:]])
                if len(vertices)>MAX_VERTICES:raise ValueError('Source vertex admission exceeded')
            elif tokens[0]=='f'and len(tokens)==4 and all(x.isdecimal()for x in tokens[1:]):
                faces.append([int(x)-1 for x in tokens[1:]])
                if len(faces)>MAX_FACES:raise ValueError('Source triangle admission exceeded')
            else:raise ValueError('Only explicit positions/positive triangle indices are admitted; no external OBJ bindings')
    v=np.asarray(vertices,np.float32);f=np.asarray(faces,np.int32)
    if v.ndim!=2 or f.ndim!=2 or v.shape[1]!=3 or f.shape[1]!=3 or not len(v)or not len(f)or not np.isfinite(v).all()or f.min()<0 or f.max()>=len(v):raise ValueError('Invalid finite/indexed OBJ geometry')
    return v,f

def edge_admission(v,f):
    import numpy as np
    if (v.dtype!=np.float32 or f.dtype!=np.int32 or v.ndim!=2 or f.ndim!=2 or v.shape[1]!=3 or f.shape[1]!=3
            or not 0<len(v)<=MAX_VERTICES or not 0<len(f)<=MAX_OUTPUT_FACES or not np.isfinite(v).all()or f.min()<0 or f.max()>=len(v)):raise ValueError('Invalid bounded native output')
    for lo in range(0,len(f),65536):
        t=v[f[lo:lo+65536]].astype(float)
        if not (np.linalg.norm(np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]),axis=1)>0).all():raise ValueError('Degenerate native output; no cleanup')
    duplicate=len(f)-len(np.unique(np.sort(f,axis=1),axis=0))
    e=np.concatenate((f[:,[0,1]],f[:,[1,2]],f[:,[2,0]]));u,inv,count=np.unique(np.sort(e,axis=1),axis=0,return_inverse=True,return_counts=True)
    balance=np.bincount(inv,weights=np.where(e[:,0]<e[:,1],1,-1));coincident=len(v)-len(np.unique(v,axis=0))
    if duplicate or coincident or not (count==2).all()or (balance!=0).any():raise ValueError('Native edge/duplicate/coincident geometry admission failed; no post-split or weld')
    return dict(vertices=int(len(v)),triangles=int(len(f)),edges=int(len(u)),boundary_edges=0,nonmanifold_edges=0,orientation_conflicts=0,duplicate_faces=0,coincident_positions=0,
                full_vertex_links='REQUIRED_IN_COMMON_PARENT_GATE',self_intersections='NOT_EVALUATED',appearance='INVALIDATED')

def write_ply(path,v,f):
    import numpy as np
    path=Path(path)
    if path.exists()or path.is_symlink():raise ValueError('Refusing to overwrite geometry output')
    header=f'ply\nformat binary_little_endian 1.0\ncomment CuMesh CUDA connected contours; CPU Blender BVH unsigned distance\nelement vertex {len(v)}\nproperty float x\nproperty float y\nproperty float z\nelement face {len(f)}\nproperty list uchar int vertex_indices\nend_header\n'.encode('ascii')
    rows=np.empty(len(f),dtype=[('count','u1'),('indices','<i4',(3,))]);rows['count']=3;rows['indices']=f
    fd,tmp=tempfile.mkstemp(prefix='.geometry-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb')as stream:stream.write(header);stream.write(v.astype('<f4',copy=False).tobytes());stream.write(rows.tobytes());stream.flush();os.fsync(stream.fileno())
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)

def atomic_metrics(path,value):
    payload=(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()
    if len(payload)>64*1024:raise ValueError('Native DC metrics exceed64KiB sidecar admission')
    fd,tmp=tempfile.mkstemp(prefix='.metrics-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb')as stream:stream.write(payload);stream.flush();os.fsync(stream.fileno())
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('input','output','metrics','blender','native-sha256'):parser.add_argument('--'+name,required=True)
    parser.add_argument('--parent-pid',type=int,required=True);parser.add_argument('--resolution',type=int,choices=(32,64,128),default=32)
    parser.add_argument('--band',type=float,choices=(1.,),default=1.);parser.add_argument('--seconds',type=float,default=180.)
    parser.add_argument('--threads',type=int,default=8);parser.add_argument('--retain-all',action='store_true');parser.add_argument('--capture-field',action='store_true')
    parser.add_argument('--witness-roi',help='Explicit version1 input-frame ROI JSON; open witness PLY only, not final reconstruction')
    args=parser.parse_args()
    if args.parent_pid<=1 or os.getppid()!=args.parent_pid:raise RuntimeError('Native DC direct caller changed')
    if ctypes.CDLL(None,use_errno=True).prctl(1,signal.SIGKILL,0,0,0):raise OSError(ctypes.get_errno(),'prctl')
    if os.getppid()!=args.parent_pid:raise RuntimeError('Native DC caller changed during prctl')
    if not 1<=args.seconds<=180 or not 1<=args.threads<=8 or not args.retain_all:raise ValueError('DC requires bounded seconds/threads and explicit retain-all unsigned policy')
    root=Path(__file__).resolve().parent;output=Path(args.output);metrics=Path(args.metrics);source=Path(args.input)
    if (not output.is_absolute()or output.parent.resolve()!=output.parent or not output.parent.is_dir()or output.exists()or output.is_symlink()
            or not metrics.is_absolute()or metrics.parent!=output.parent or metrics.exists()or metrics.is_symlink()):raise ValueError('Output/metrics must be new files in one owned canonical job directory')
    spec=json.loads((root/'runtime-spec.json').read_text());blender=Path(args.blender)
    if not blender.is_absolute()or not blender.is_file()or sha(blender)!=spec['blender_sha256']:raise ValueError('CuMesh DC requires the parent-verified qualified Blender binary; no arbitrary executable')
    library=root.parent/'lib/_h3_dc_contours.cpython-312-aarch64-linux-gnu.so'
    if sha(library)!=args.native_sha256:raise ValueError('Owned native contour binary identity changed')
    started=time.monotonic();deadline=started+args.seconds;report=dict(status='failed',backend='CuMesh CUDA connected contours',distance_backend='CPU Blender BVHTree.FromPolygons',resolution=args.resolution,band=1.,policy='retain_all_unsigned_shells',parent_pid=args.parent_pid,pid=os.getpid(),process_group=os.getpgrp(),self_intersections='NOT_EVALUATED');provider=None
    try:
        import numpy as np
        import torch
        if sys.version_info[:3]!=(3,12,16)or torch.__version__!='2.12.0+cu130'or np.__version__!='2.4.6':raise RuntimeError('Owned CPython/Torch/NumPy ABI differs')
        if not Path(torch.__file__).resolve().is_relative_to(Path(sys.prefix).resolve())or not Path(np.__file__).resolve().is_relative_to(Path(sys.prefix).resolve()):raise RuntimeError('Shared Torch/NumPy origins are not owned')
        torch.cuda.set_device(0);torch.set_num_threads(args.threads)
        if torch.cuda.get_device_capability(0)!=(12,1):raise RuntimeError('Native DC initial lane requires GB10 sm121')
        module_spec=importlib.util.spec_from_file_location('_h3_dc_contours',library);native=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(native)
        sys.path.insert(0,str(root));import dc_wrapper as wrapper
        from blender_bvh_adapter import BlenderBVHAdapter
        wrapper._C=native;wrapper._CAPTURE_FIELDS=args.capture_field
        required=('hashmap_insert_3d_idx_as_val_cuda','hashmap_lookup_3d_cuda','get_sparse_voxel_grid_active_vertices','contour_dual_contour')
        if not all(hasattr(native,name)for name in required)or hasattr(native,'simple_dual_contour'):raise RuntimeError('Expected exactly the qualified four-binding contour subset, no old contour fallback')
        roi=None
        if args.witness_roi:
            from dc_roi_witness import load_roi
            roi=load_roi(args.witness_roi,args.resolution)
            report.update(scope='local_hole_witness_only',roi_sha256=roi['sha256'],protected_slab_voxels=2,boundary_guard_voxels=8)
        source_sha=sha(source);v,f=read_obj(source,deadline)
        if sha(source)!=source_sha:raise ValueError('Staged geometry changed during parse')
        if roi is not None:
            from dc_roi_witness import bind_source
            report['roi_source_binding']=bind_source(roi,v,f,deadline=deadline)
        V,F=torch.tensor(v,device='cuda'),torch.tensor(f,device='cuda')
        provider=BlenderBVHAdapter(V,F,directory=output.parent/'distance-worker',deadline=deadline,blender=blender,cpu_threads=args.threads)
        tick=time.monotonic();vertices,faces=wrapper.reconstruct_mesh_dc_quad(V,F,resolution=args.resolution,band=1,verbose=False,bvh=provider,remove_inner_faces=False,**({'witness_roi':roi}if roi is not None else {}));torch.cuda.synchronize();wall=time.monotonic()-tick
        result_v,result_f=vertices.cpu().numpy(),faces.cpu().numpy()
        face_arc_proof=None
        if roi is not None:
            from dc_roi_witness import open_admission
            data=wrapper.face_arc_provenance()
            try:admission=open_admission(result_v,result_f,data['vertex_tokens'],data['coords'],args.resolution,roi,deadline=deadline)
            finally:wrapper._ARC_SOURCE.clear()
        else:
            try:
                admission=edge_admission(result_v,result_f)
            except ValueError as error:
                if str(error)!='Native edge/duplicate/coincident geometry admission failed; no post-split or weld':raise
                from dc_face_arcs import resolve_face_arcs
                result_v,result_f,face_arc_proof=resolve_face_arcs(result_v,result_f,wrapper.face_arc_provenance,deadline=deadline,face_limit=MAX_OUTPUT_FACES)
                admission=edge_admission(result_v,result_f)  # Identical strict gate after geometric realization.
            finally:wrapper._ARC_SOURCE.clear()
        if time.monotonic()>=deadline:raise TimeoutError('Native DC reconstruction deadline exceeded')
        provider.close();worker=json.loads((output.parent/'distance-worker/worker-result.json').read_text())
        if worker['status']!='CLOSED'or worker['source_faces']!=len(f)or any(x['missing']or x['filled']for x in worker['batches']):raise ValueError('BVH source/occupancy/close contract failed')
        if sha(source)!=source_sha or not np.array_equal(V.cpu().numpy(),v)or not np.array_equal(F.cpu().numpy(),f):raise ValueError('Staged source geometry changed')
        if args.capture_field:np.savez(output.parent/'dc-field.npz',vertices=result_v,faces=result_f,**wrapper._TRACE)
        write_ply(output,result_v,result_f)
        report.update(status='witness_proposal'if roi is not None else 'geometry_proposal',input_sha256=source_sha,output_sha256=sha(output),output_bytes=output.stat().st_size,source_vertices=int(len(v)),source_triangles=int(len(f)),output=admission,
                      native=wrapper._METRICS,shared_face_arcs=face_arc_proof,distance_batches=provider.facts,distance_ready=provider.ready,worker_result=worker,
                      wrapper_wall_seconds_including_CPU=wall,gpu_kernel_only_time='NOT_MEASURED',elapsed_seconds=time.monotonic()-started,native_sha256=sha(library),source_preserved=True)
    except BaseException as error:report.update(error_class=type(error).__name__,error=str(error),elapsed_seconds=time.monotonic()-started);raise
    finally:
        try:
            if provider is not None and provider.process is not None:provider.close(abort=True)
        finally:atomic_metrics(metrics,report)
    print(json.dumps(dict(status=report['status'],output=str(output),metrics=str(metrics),vertices=report['output']['vertices'],triangles=report['output']['triangles'])),flush=True)

if __name__=='__main__':main()
