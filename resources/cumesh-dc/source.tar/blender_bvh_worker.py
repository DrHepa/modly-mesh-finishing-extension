"""One owned Blender process/BVH; bounded typed sparse query batches on stdin."""
import argparse, ctypes, hashlib, json, os, signal, sys, tempfile, time, zipfile
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--directory',required=True);parser.add_argument('--parent-pid',type=int,required=True);parser.add_argument('--seconds',type=float,required=True)
args=parser.parse_args(sys.argv[sys.argv.index('--')+1:])
if args.parent_pid<=1 or os.getppid()!=args.parent_pid:raise RuntimeError('BVH direct caller changed')
if ctypes.CDLL(None,use_errno=True).prctl(1,signal.SIGKILL,0,0,0):raise OSError(ctypes.get_errno(),'prctl')
if os.getppid()!=args.parent_pid:raise RuntimeError('BVH direct caller changed during prctl')
import bpy
import numpy as np
from mathutils.bvhtree import BVHTree
root=Path(args.directory);assert root.is_absolute() and root.resolve()==root and 1<=args.seconds<=180
started=time.monotonic();deadline=started+args.seconds;ordinal=0;aggregate=0;stats=dict(status='FAILED',batches=[],logical_source_objects=1)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def reply(value):print('BVH_REPLY '+json.dumps(value,separators=(',',':')),flush=True)
def load(path,names,maximum):
    if path.is_symlink() or path.parent!=root or path.stat().st_size>maximum:raise ValueError('Invalid owned BVH input size/path')
    with zipfile.ZipFile(path)as z:
        if set(z.namelist())!={name+'.npy'for name in names} or any(x.compress_type!=zipfile.ZIP_STORED for x in z.infolist())or sum(x.file_size for x in z.infolist())>maximum:raise ValueError('Invalid bounded BVH typed archive')
        for name in names:
            with z.open(name+'.npy')as stream:
                if np.lib.format.read_magic(stream)!=(1,0):raise ValueError('Unsupported BVH NPY header version')
                shape,fortran,dtype=np.lib.format.read_array_header_1_0(stream)
                limit=524288 if name=='queries'else 2_000_000
                if dtype!=(np.dtype(np.int32)if name=='faces'else np.dtype(np.float32))or fortran or len(shape)!=2 or shape[1]!=3 or not 0<shape[0]<=limit:raise ValueError('BVH NPY header rejected before allocation')
    with np.load(path,allow_pickle=False)as z:return [z[name]for name in names]
def save(path,**arrays):
    if path.exists()or path.is_symlink():raise ValueError('BVH output already exists')
    fd,tmp=tempfile.mkstemp(prefix='.typed-',dir=root)
    try:
        with os.fdopen(fd,'wb')as stream:np.savez(stream,**arrays);stream.flush();os.fsync(stream.fileno())
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
try:
    bpy.ops.wm.read_factory_settings(use_empty=True);assert len(bpy.context.scene.objects)==0
    source=root/'source.npz';vertices,faces=load(source,('vertices','faces'),64*1024**2)
    if (vertices.dtype!=np.float32 or faces.dtype!=np.int32 or vertices.ndim!=2 or faces.ndim!=2 or vertices.shape[1]!=3 or faces.shape[1]!=3
            or not 0<len(vertices)<=2_000_000 or not 0<len(faces)<=2_000_000 or not np.isfinite(vertices).all()or faces.min()<0 or faces.max()>=len(vertices)):raise ValueError('Unsupported BVH source shapes/dtypes/finite/indices')
    for lo in range(0,len(faces),65536):
        t=vertices[faces[lo:lo+65536]];cross=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]);cross64=np.cross(t[:,1].astype(float)-t[:,0],t[:,2].astype(float)-t[:,0])
        norm2=(cross*cross).sum(1,dtype=np.float32)
        if not np.isfinite(cross).all()or not np.isfinite(norm2).all()or not (norm2>0).all()or not (np.linalg.norm(cross64,axis=1)>0).all():raise ValueError('Degenerate/Float32-unsupported source triangle; no face omitted')
    source_sha=sha(source);tick=time.monotonic();tree=BVHTree.FromPolygons(vertices.tolist(),faces.tolist(),all_triangles=True,epsilon=0.0)
    stats.update(source_vertices=len(vertices),source_faces=len(faces),source_sha256=source_sha,bvh_build_seconds=time.monotonic()-tick,blender=bpy.app.version_string,python=sys.version,numpy=np.__version__,scene_objects=0)
    reply(dict(stats,status='READY'))
    while True:
        line=sys.stdin.buffer.readline(8193)
        if not line:raise RuntimeError('BVH caller closed without close command')
        if len(line)>8192:raise ValueError('BVH command exceeds framing limit')
        if time.monotonic()>=deadline:raise TimeoutError('BVH worker deadline')
        command=json.loads(line)
        if command.get('operation')=='close':break
        if command.get('operation')!='query'or command.get('ordinal')!=ordinal or ordinal>=32:raise ValueError('Unexpected BVH batch operation/ordinal')
        path=root/f'query-{ordinal:03d}.npz';queries,=load(path,('queries',),16*1024**2)
        if sha(path)!=command.get('sha256')or queries.dtype!=np.float32 or queries.ndim!=2 or queries.shape[1]!=3 or not 0<len(queries)<=524288 or len(queries)!=command.get('rows')or not np.isfinite(queries).all():raise ValueError('Invalid BVH query identity/shape/dtype')
        aggregate+=len(queries)
        if aggregate>4_000_000:raise ValueError('BVH aggregate query admission exceeded')
        nearest=np.empty_like(queries);distances=np.empty(len(queries),np.float32);ids=np.empty(len(queries),np.int32);tick=time.monotonic()
        for i,q in enumerate(queries):
            if i%4096==0 and time.monotonic()>=deadline:raise TimeoutError('BVH nearest-query deadline')
            point,normal,index,distance=tree.find_nearest(q)
            if point is None or normal is None or index is None or distance is None or not 0<=index<len(faces)or not np.isfinite(tuple(normal)).all():raise ValueError(f'BVH_NO_HIT row={i}; no default/fill')
            nearest[i]=point;distances[i]=distance;ids[i]=index
        query_seconds=time.monotonic()-tick
        if not np.isfinite(nearest).all()or not np.isfinite(distances).all()or (distances<0).any():raise ValueError('BVH returned nonfinite/negative distance')
        output=root/f'answer-{ordinal:03d}.npz';save(output,distances=distances,nearest=nearest,triangle_ids=ids)
        fact=dict(status='QUERY_COMPLETE',ordinal=ordinal,rows=len(queries),source_sha256=source_sha,input_sha256=sha(path),output_sha256=sha(output),cpu_query_seconds=query_seconds,cpu_query_and_output_seconds=time.monotonic()-tick,missing=0,filled=0)
        stats['batches'].append(fact);reply(fact);ordinal+=1
    if sha(source)!=source_sha or len(bpy.context.scene.objects)!=0:raise ValueError('BVH source/scene changed')
    stats.update(status='CLOSED',aggregate_queries=aggregate,total_seconds=time.monotonic()-started);reply(dict(status='CLOSED',batches=ordinal,aggregate_queries=aggregate))
except BaseException as error:
    stats.update(error_class=type(error).__name__,error=str(error));reply(dict(status='FAILED',error_class=type(error).__name__,error=str(error)));raise
finally:(root/'worker-result.json').write_text(json.dumps(stats,indent=2)+'\n')
