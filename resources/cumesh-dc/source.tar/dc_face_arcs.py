# SPDX-License-Identifier: GPL-3.0-or-later
"""Controller-only geometric realization of proven parallel dual face arcs.

The MIT CUDA contour generator remains the source of every cell/slot/quad.
No weld, displacement of original vertices, face removal or shell selection.
"""
import time
import numpy as np

MAX_FACES=1_250_000
MAX_CELLS=500_000
MAX_ARCS=4096
MAX_EXTRA_BYTES=512*1024**2
_NEIGHBORS=np.array([[[0,0,0],[0,0,1],[0,1,1],[0,1,0]],[[0,0,0],[1,0,0],[1,0,1],[0,0,1]],[[0,0,0],[0,1,0],[1,1,0],[1,0,0]]],np.int32)


def _face_pairs(s):
    # Same positive-axis corner cycle and strict sign as contour_dual.cu.
    # Prove the determinant/denominator signs are robust also to an FMA,
    # rather than changing the native decider near an arithmetic tie.
    a,b,c,d=map(float,s);det=a*c-b*d;den=a+c-b-d
    eps=32*np.finfo(float).eps
    if not np.isfinite(s).all() or not np.isfinite(det) or not np.isfinite(den) or abs(det)<=eps*(abs(a*c)+abs(b*d)) or abs(den)<=eps*(abs(a)+abs(b)+abs(c)+abs(d)):
        raise ValueError('DC face-arc saddle sign is unresolved')
    if any((s[i]<0)==(s[(i+1)%4]<0) for i in range(4)):raise ValueError('DC face-arc face is not checkerboard')
    inside=(det<0)!=(den<0)
    pairs=[((i+3)%4,i) for i in range(4) if (s[i]<0)!=inside]
    if len(pairs)!=2:raise ValueError('DC face-arc pairing is unresolved')
    return pairs


def resolve_face_arcs(vertices,faces,provenance,*,deadline,face_limit=MAX_FACES):
    """Called only after the unchanged generic native admission has refused.

    Provenance is lazy: successful stock output never copies contour buffers
    to CPU or invokes this helper. All arithmetic changes concern new arcs.
    """
    def check():
        if time.monotonic()>=deadline:raise TimeoutError('DC face-arc deadline exceeded')
    check();v=vertices;f=faces
    if v.dtype!=np.float32 or f.dtype!=np.int32 or v.ndim!=2 or f.ndim!=2 or v.shape[1]!=3 or f.shape[1]!=3 or not 0<len(f)<=face_limit or len(f)%2:
        raise ValueError('DC face-arc input shape/count is unsupported')
    if not 0<len(v)<=2_000_000 or not np.isfinite(v).all() or f.min()<0 or f.max()>=len(v):raise ValueError('DC face-arc finite/index admission failed')
    if len(v)!=len(np.unique(v,axis=0)) or len(f)!=len(np.unique(np.sort(f,axis=1),axis=0)):raise ValueError('DC face arcs never repair coincident vertices or duplicate faces')
    directed=np.stack((f,np.roll(f,-1,axis=1)),axis=-1).reshape(-1,2)
    edges,inverse,counts=np.unique(np.sort(directed,axis=1),axis=0,return_inverse=True,return_counts=True)
    balance=np.bincount(inverse,weights=np.where(directed[:,0]<directed[:,1],1,-1))
    bad=np.flatnonzero(counts!=2)
    if not len(bad) or len(bad)>MAX_ARCS or np.any(counts[bad]!=4) or np.any(balance):raise ValueError('DC face arcs require only balanced degree4 edges')
    if len(v)+2*len(bad)>2_000_000 or len(f)+4*len(bad)>min(face_limit,MAX_FACES):raise ValueError('DC face-arc output face budget exceeded')
    data=provenance();check()
    if sum(getattr(x,'nbytes',0) for x in data.values())+256*(len(v)+len(f)+len(data['grid_vertices']))+64*len(data['coords'])>MAX_EXTRA_BYTES:raise MemoryError('DC face-arc controller memory bound exceeded')
    coords=np.asarray(data['coords']);tokens=np.asarray(data['vertex_tokens']);quads=np.asarray(data['quads']);owners=np.asarray(data['owners']);slots=np.asarray(data['edge_slots']);cell_counts=np.asarray(data['counts']);grid=np.asarray(data['grid_vertices']);scalar=np.asarray(data['scalar'])
    n=len(coords);resolution=data['resolution'];center=np.asarray(data['center'],np.float32);scale=np.float32(data['scale'])
    if not 0<n<=MAX_CELLS or coords.shape!=(n,3) or tokens.shape!=(len(v),) or quads.shape!=(len(f)//2,4) or owners.shape!=(len(quads),2) or slots.shape!=(n,12) or cell_counts.shape!=(n,) or grid.shape!=(len(scalar),3):raise ValueError('DC face-arc native provenance shape mismatch')
    if type(resolution)is not int or resolution not in (32,64,128) or center.shape!=(3,) or not np.isfinite(center).all() or not np.isfinite(scale) or scale<=0:raise ValueError('DC face-arc transform is invalid')
    if any(not np.issubdtype(x.dtype,np.integer) for x in (tokens,quads,owners,slots,cell_counts)) or tokens.min()<0 or tokens.max()>=4*n or len(np.unique(tokens))!=len(tokens):raise ValueError('DC face-arc inverse slot map is invalid')
    if not np.isfinite(scalar).all() or grid.dtype!=np.int32 or scalar.dtype!=np.float32 or coords.dtype!=np.int32:raise ValueError('DC face-arc field ABI differs')
    # Native sparse-corner queries may repeat coordinates. This is field
    # identity, never mesh welding: every repeated F32 value must be bit-exact.
    field={}
    for i,(p,s) in enumerate(zip(grid,scalar)):
        key=tuple(map(int,p))
        if key in field and field[key].view(np.uint32)!=s.view(np.uint32):raise ValueError('DC face-arc repeated field corner disagrees')
        field[key]=s
        if i%4096==0:check()
    def sample(p):
        try:return field[tuple(map(int,p))]
        except KeyError as error:raise ValueError('DC face-arc corner is missing') from error
    row_for_vertex=tokens//4;slot_for_vertex=tokens%4
    positions={tuple(p) for p in v};added=[];splits={};details=[]
    # One rare incidence map, not metadata vectors for every triangle/quad.
    wanted={int(k):[] for k in bad}
    for i,k in enumerate(inverse):
        if int(k) in wanted:wanted[int(k)].append(i//3)
        if i%65536==0:check()
    for edge_id in bad:
        check();u,w=map(int,edges[edge_id]);cu=coords[row_for_vertex[u]];cw=coords[row_for_vertex[w]];delta=cw.astype(np.int64)-cu
        axes=np.flatnonzero(delta)
        if len(axes)!=1 or abs(int(delta[axes[0]]))!=1:raise ValueError('DC degree4 edge is not a shared cell face')
        normal=int(axes[0]);plane=np.maximum(cu,cw);ax=(normal+1)%3;ay=(normal+2)%3
        corners=np.tile(plane,(4,1));corners[1,ax]+=1;corners[2,ax]+=1;corners[2,ay]+=1;corners[3,ay]+=1
        values=np.array([sample(p) for p in corners],np.float32);pairs=_face_pairs(values)
        by_slot={};orientation={};seen=set()
        for face_id in wanted[int(edge_id)]:
            qi=face_id//2
            if qi in seen:raise ValueError('DC degree4 edge is a quad diagonal or duplicate quad')
            seen.add(qi);q=quads[qi]
            if not np.issubdtype(quads.dtype,np.integer) or q.min()<0 or q.max()>=len(v) or len(set(map(int,q)))!=4:raise ValueError('DC face-arc quad indices are invalid')
            if not any(set((int(q[k]),int(q[(k+1)%4])))=={u,w} for k in range(4)):raise ValueError('DC degree4 edge is not a quad side')
            row,axis=map(int,owners[qi])
            if not 0<=row<n or axis not in (0,1,2):raise ValueError('DC face-arc owner is invalid')
            cell_rows=row_for_vertex[q];cell_slots=slot_for_vertex[q]
            if not np.array_equal(coords[cell_rows],coords[row]+_NEIGHBORS[axis]):raise ValueError('DC face-arc quad cell rectangle differs')
            primal=coords[row].copy();primal[np.arange(3)!=axis]+=1;high=primal.copy();high[axis]+=1
            s0,s1=sample(primal),sample(high)
            if (s0<0)==(s1<0):raise ValueError('DC face-arc owner has no primal crossing')
            relative=primal-coords[cell_rows];other=[k for k in range(3) if k!=axis]
            if np.any(relative<0) or np.any(relative>1) or np.any(relative[:,axis]!=0):raise ValueError('DC face-arc local primal offsets are invalid')
            codes=axis*4+2*relative[:,other[0]]+relative[:,other[1]]
            if np.any(cell_slots>=cell_counts[cell_rows]) or not np.array_equal(slots[cell_rows,codes],cell_slots):raise ValueError('DC face-arc flux slot ownership differs')
            templates=([0,2,1,0,3,2],[0,3,1,3,2,1]) if s0<0 else ([0,1,2,0,2,3],[0,1,3,3,1,2])
            actual=f[2*qi:2*qi+2].reshape(-1)
            if not any(np.array_equal(actual,q[t]) for t in templates):raise ValueError('DC face-arc original triangle pairing/winding differs')
            found=[]
            for k in range(4):
                low=np.minimum(corners[k],corners[(k+1)%4]);difference=np.abs(corners[k]-corners[(k+1)%4]);edge_axis=int(np.flatnonzero(difference)[0])
                if edge_axis==axis and np.array_equal(primal,low):found.append(k)
            if len(found)!=1 or found[0] in by_slot:raise ValueError('DC face-arc quads are not four distinct common-face crossings')
            k=found[0];by_slot[k]=face_id;tri=f[face_id]
            orientation[k]=next((1 if a==u else -1 for a,b in zip(tri,np.roll(tri,-1)) if {int(a),int(b)}=={u,w}),0)
        if len(by_slot)!=4:raise ValueError('DC face-arc four-quad incidence is incomplete')
        hits=[]
        for k in range(4):
            low=np.minimum(corners[k],corners[(k+1)%4]);axis=int(np.flatnonzero(corners[k]!=corners[(k+1)%4])[0]);high=low.copy();high[axis]+=1
            s0,s1=sample(low),sample(high);den=np.float32(s1-s0);t=np.float32(-s0/den)
            if not np.isfinite(t) or not 0<=t<=1:raise ValueError('DC face-arc Hermite crossing is invalid')
            p=low.astype(np.float32);p[axis]=np.float32(p[axis]+t);hits.append(p)
        for a,b in pairs:
            if not orientation[a] or orientation[a]!=-orientation[b]:raise ValueError('DC face-arc incidences do not oppose')
            # New independent controller geometry: chord midpoint of the two
            # native F32 Hermite crossings, then the unchanged F32 world map.
            midpoint=((hits[a].astype(float)+hits[b].astype(float))*.5).astype(np.float32)
            point=((midpoint/np.float32(resolution)-np.float32(.5))*scale+center).astype(np.float32)
            key=tuple(point)
            if not np.isfinite(point).all() or key in positions:raise ValueError('DC face-arc midpoint is coincident or nonfinite')
            positions.add(key);idx=len(v)+len(added);added.append(point)
            for slot in (a,b):splits.setdefault(by_slot[slot],[]).append((u,w,idx))
        if len(details)<16:details.append(dict(endpoints=[u,w],plane_origin=plane.tolist(),normal_axis=normal,arc_edge_pairs=pairs))
    result=[]
    for i,tri in enumerate(f):
        if i%4096==0:check()
        local=[tuple(map(int,tri))]
        for u,w,mid in splits.get(i,[]):
            found=False
            for j,t in enumerate(local):
                for k in range(3):
                    if {t[k],t[(k+1)%3]}=={u,w}:
                        local[j]=(t[k],mid,t[(k+2)%3]);local.append((mid,t[(k+1)%3],t[(k+2)%3]));found=True;break
                if found:break
            if not found:raise ValueError('DC face-arc original triangle side was lost')
        result.extend(local)
    out_v=np.concatenate((v,np.array(added,np.float32)));out_f=np.array(result,np.int32)
    if len(out_f)!=len(f)+4*len(bad) or len(out_v)!=len(v)+2*len(bad):raise ValueError('DC face-arc subdivision count mismatch')
    check()
    return out_v,out_f,dict(compute_backend='CPU NumPy geometric realization from native CUDA provenance; no contour replacement',resolved_degree4_edges=int(len(bad)),added_vertices=len(added),added_triangles=len(out_f)-len(f),original_vertex_positions_byteexact=out_v[:len(v)].tobytes()==v.tobytes(),
        witness='Native cell slots/owner crossings/original quads + unchanged shared-face saddle decider',details=details,details_omitted=max(0,len(bad)-len(details)))
