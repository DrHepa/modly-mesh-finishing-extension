# SPDX-License-Identifier: GPL-3.0-or-later
"""Explicit open ROI witnesses, never reconstruction or closed-shell admission.

All coordinates and the protected chart are in the unchanged source OBJ frame.
The full source remains the distance authority. CUDA slots/sign/triangulation
are unchanged; only primal crossings with out-of-grid incidence are omitted.
"""
import hashlib
import json
import math
import time
from fractions import Fraction as Q
from pathlib import Path
import numpy as np

MAX_WORK_BYTES=128*1024**2


def lookup_incident_cells(native,hashmap,coords,neighbors,resolution):
    """No out-of-grid key enters the flattening hash; check every in-box row."""
    import torch
    inside=((neighbors>=0)&(neighbors<resolution)).all(dim=2)
    expected=neighbors[inside]
    lookup=torch.full(neighbors.shape[:2],-1,dtype=torch.int32,device=coords.device)
    if len(expected):
        keys=torch.cat((torch.zeros((len(expected),1),dtype=torch.int32,device=coords.device),expected),dim=1)
        found=native.hashmap_lookup_3d_cuda(*hashmap,keys,resolution,resolution,resolution).int()
        if not ((found>=0)&(found<len(coords))).all().item():
            raise ValueError('A crossed primal edge lacks four valid sparse cells; in-box ROI gap')
        if not torch.equal(coords[found.long()],expected):raise ValueError('ROI sparse hash aliases another in-box cell')
        lookup[inside]=found
    return lookup,inside.all(dim=1)


def load_roi(path,resolution):
    path=Path(path)
    if not path.is_absolute() or path.is_symlink() or not path.is_file() or path.stat().st_size>16384:
        raise ValueError('ROI must be one bounded physical absolute JSON file')
    raw=path.read_bytes();row=json.loads(raw)
    if set(row)!={'schema','scope','center','extent','protected_polygon','normal','guard_voxels'} or type(row['schema'])is not int or row['schema']!=1 or row['scope']!='local_hole_witness_only':
        raise ValueError('Unsupported witness-only ROI schema')
    if type(resolution)is not int or resolution not in (32,64,128) or type(row['guard_voxels'])is not int or row['guard_voxels']!=8:
        raise ValueError('ROI resolution/guard contract differs')
    center=np.asarray(row['center'],float);normal=np.asarray(row['normal'],float);ring=np.asarray(row['protected_polygon'],float)
    if center.shape!=(3,) or normal.shape!=(3,) or ring.ndim!=2 or ring.shape[1]!=3 or not 3<=len(ring)<=32 or not np.isfinite(np.concatenate((center,normal,ring.ravel()))).all():
        raise ValueError('Invalid finite ROI chart')
    extent=row['extent']
    if type(extent)not in (int,float) or not math.isfinite(extent) or extent<=0 or not np.any(normal):
        raise ValueError('Invalid ROI metric/normal')
    center32=center.astype(np.float32)
    if not np.isfinite(center32).all() or np.any(np.spacing(np.abs(center32)).astype(float)>extent/resolution/64):
        raise ValueError('ROI frame cannot resolve the requested voxel')
    # The complete footprint (not just five samples) is certified below using
    # an enclosing ball; it need not be triangulated or guessed from contacts.
    pitch=float(extent)/resolution
    # normal is the input-frame ray/extrusion direction (A^-1 n_world),
    # not the local plane covector (A^T n_world) under shear/nonuniform scale.
    radius=max(np.abs(ring-center).sum(1))+2*pitch*np.abs(normal).sum()
    if float(np.max(np.abs(center-center32.astype(float))))+radius+8*pitch>=extent/2-2*pitch:
        raise ValueError('ROI lacks protected-slab boundary headroom')
    row.update(center=center32,chart_center=center,normal=normal,protected_polygon=ring,
               extent=float(extent),pitch=pitch,sha256=hashlib.sha256(raw).hexdigest())
    return row


def bind_source(roi,v,f,*,deadline):
    """Bind the protected polygon to real oriented source boundary edges."""
    ring=roi['protected_polygon'];center=ring.mean(0)
    if not np.array_equal(center,roi['chart_center']) or not np.array_equal(center.astype(np.float32),roi['center']):
        raise ValueError('ROI center is not the exact original boundary chart center')
    ids=[]
    for p in ring:
        if time.monotonic()>=deadline:raise TimeoutError('ROI source binding deadline')
        matches=np.flatnonzero(np.all(v==p,axis=1))
        if len(matches)!=1:raise ValueError('ROI polygon does not uniquely identify original source vertices')
        ids.append(int(matches[0]))
    if len(set(ids))!=len(ids):raise ValueError('Repeated ROI source boundary vertex')
    found={tuple(pair):0 for pair in zip(ids,ids[1:]+ids[:1])}
    for lo in range(0,len(f),4096):
        if time.monotonic()>=deadline:raise TimeoutError('ROI source boundary deadline')
        rows=f[lo:lo+4096]
        for a,b in found:
            for k in range(3):
                if np.any((rows[:,k]==b)&(rows[:,(k+1)%3]==a)):raise ValueError('ROI ring is not an oriented source boundary')
                found[a,b]+=int(np.count_nonzero((rows[:,k]==a)&(rows[:,(k+1)%3]==b)))
    if any(count!=1 for count in found.values()):raise ValueError('ROI polygon contains a missing/interior source edge')
    diameter=max(float(np.linalg.norm(a-b))for a in ring for b in ring)
    expected=.4*diameter
    if not math.isclose(roi['pitch'],expected,rel_tol=4*np.finfo(float).eps,abs_tol=0):
        raise ValueError('ROI voxel is not the declared source-backed 0.4 boundary diameter')
    return dict(source_boundary_vertices=ids,source_boundary_edges=len(ids),boundary_diameter=diameter,
                voxel_over_boundary_diameter=roi['pitch']/diameter,full_original_source=True)


def open_admission(v,f,tokens,coords,resolution,roi,*,deadline):
    """Strict open manifold + exact boundary separation, not final GLB safety."""
    def check():
        if time.monotonic()>=deadline:raise TimeoutError('ROI witness admission deadline')
    check()
    if (v.dtype!=np.float32 or f.dtype!=np.int32 or v.ndim!=2 or f.ndim!=2 or v.shape[1]!=3 or f.shape[1]!=3
            or not 0<len(v)<=2_000_000 or not 0<len(f)<=1_250_000 or not np.isfinite(v).all() or f.min()<0 or f.max()>=len(v)):
        raise ValueError('Invalid bounded ROI output')
    work=1024*(len(v)+len(f))+getattr(coords,'nbytes',0)+getattr(tokens,'nbytes',0)
    if work>MAX_WORK_BYTES:raise MemoryError('ROI witness admission working-byte cap exceeded')
    if len(np.unique(v,axis=0))!=len(v) or len(np.unique(np.sort(f,axis=1),axis=0))!=len(f):
        raise ValueError('Coincident/duplicate ROI geometry is forbidden')
    for lo in range(0,len(f),4096):
        check();t=v[f[lo:lo+4096]].astype(float)
        if not (np.linalg.norm(np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]),axis=1)>0).all():raise ValueError('Degenerate ROI triangle')
    directed=np.stack((f,np.roll(f,-1,axis=1)),axis=-1).reshape(-1,2)
    edges,inverse,counts=np.unique(np.sort(directed,axis=1),axis=0,return_inverse=True,return_counts=True)
    balance=np.bincount(inverse,weights=np.where(directed[:,0]<directed[:,1],1,-1))
    if (counts>2).any() or ((counts==2)&(balance!=0)).any():raise ValueError('Nonmanifold/nonorientable ROI geometry')
    boundary=edges[counts==1]
    if not 0<len(boundary)<=32768:raise ValueError('ROI requires a bounded explicit open boundary')
    tokens=np.asarray(tokens);coords=np.asarray(coords)
    if tokens.shape!=(len(v),) or coords.ndim!=2 or coords.shape[1]!=3 or tokens.min()<0 or tokens.max()>=4*len(coords):
        raise ValueError('ROI inverse native slot identity differs')
    cells=coords[tokens//4]
    for a,b in boundary:
        if not any(cells[a,axis]==side and cells[b,axis]==side for axis in range(3) for side in (0,resolution-1)):
            raise ValueError('ROI boundary does not belong to the explicit outer cell layer')
    # Every vertex link must be one cycle (interior) or one path (boundary).
    # An otherwise manifold edge census cannot hide a disconnected bow tie.
    links=[{}for _ in v];boundary_vertices=set(map(int,boundary.ravel()))
    for row,tr in enumerate(f):
        if row%4096==0:check()
        for k in range(3):
            i,a,b=map(int,(tr[k],tr[(k+1)%3],tr[(k+2)%3]));g=links[i]
            g.setdefault(a,[]).append(b);g.setdefault(b,[]).append(a)
    for i,g in enumerate(links):
        if i%4096==0:check()
        if not g:raise ValueError('Unreferenced ROI output vertex')
        degrees=[len(a)for a in g.values()];seen=set();stack=[next(iter(g))]
        while stack:
            a=stack.pop()
            if a not in seen:seen.add(a);stack.extend(b for b in g[a]if b not in seen)
        if len(seen)!=len(g) or any(d not in (1,2)for d in degrees) or degrees.count(1)!=(2 if i in boundary_vertices else 0):
            raise ValueError('Disconnected/nonmanifold ROI vertex link')
    exact=lambda x:tuple(Q(float(a))for a in x)
    center=exact(roi['chart_center']);normal=exact(roi['normal']);pitch=Q(roi['pitch'])
    radius=max(sum(abs(a-b)for a,b in zip(exact(p),center))for p in roi['protected_polygon'])+2*pitch*sum(abs(a)for a in normal)
    guarded=radius+8*pitch;minimum=None
    for i,(a,b)in enumerate(boundary):
        if i%128==0:check()
        x=tuple(a-b for a,b in zip(exact(v[a]),center));d=tuple(a-b for a,b in zip(exact(v[b]),exact(v[a])))
        den=sum(a*a for a in d)
        if den<=0:raise ValueError('Zero-length ROI boundary segment')
        t=max(Q(0),min(Q(1),-sum(a*b for a,b in zip(x,d))/den));distance=sum((a+t*b)**2 for a,b in zip(x,d))
        if distance<=guarded**2:raise ValueError('ROI boundary enters the protected full slab plus margin')
        minimum=distance if minimum is None else min(minimum,distance)
    check()
    return dict(vertices=len(v),triangles=len(f),boundary_edges=len(boundary),nonmanifold_edges=0,orientation_conflicts=0,
        duplicate_faces=0,coincident_positions=0,bad_vertex_links=0,working_bytes_bound=work,
        boundary_certificate=dict(arithmetic='Exact rational over serialized F32 vertices/F64 chart; all boundary segments',
            domain='Full protected polygon convex hull extruded +/-2 voxels along declared normal, plus 8-voxel margin',
            enclosing_radius=float(radius),minimum_segment_distance=math.sqrt(float(minimum)),guard_voxels=8,
            boundary_outside_certificate=True),self_intersections='NOT_EVALUATED',appearance='NOT_APPLICABLE_WITNESS_ONLY')
