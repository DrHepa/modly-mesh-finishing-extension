# CuMesh MIT, Jianfeng XIANG 2025, pinned d10e54; explicit-adapter-only isolated proof.
import torch
from tqdm import tqdm
_TRACE = {}
_CAPTURE_FIELDS = False
_METRICS = {}
_ARC_SOURCE = {}
def face_arc_provenance():
    """Lazy CPU evidence for the GPL controller; no alteration of CUDA output."""
    import numpy as np
    if not _ARC_SOURCE.get('retain_all'):raise ValueError('Face arcs require unchanged retain-all quad ownership')
    tensors={k:v for k,v in _ARC_SOURCE.items() if hasattr(v,'numel')}
    if sum(v.numel()*v.element_size() for v in tensors.values())>256*1024**2:raise MemoryError('DC face-arc transfer bound exceeded')
    data={k:v.cpu().numpy() for k,v in tensors.items()}
    active=data.pop('active');used=data.pop('used')
    data['vertex_tokens']=np.flatnonzero(active)[used]
    data.update(resolution=_ARC_SOURCE['resolution'],scale=_ARC_SOURCE['scale'])
    return data

def _init_hashmap(resolution, capacity, device):
    VOL = resolution * resolution * resolution
    if VOL < 2 ** 32:
        hashmap_keys = torch.full((capacity,), torch.iinfo(torch.uint32).max, dtype=torch.uint32, device=device)
    elif VOL < 2 ** 64:
        hashmap_keys = torch.full((capacity,), torch.iinfo(torch.uint64).max, dtype=torch.uint64, device=device)
    else:
        raise ValueError(f'The spatial size is too large to fit in a hashmap. Volume {VOL} > 2^64.')
    hashmap_vals = torch.empty((capacity,), dtype=torch.uint32, device=device)
    return (hashmap_keys, hashmap_vals)

def reconstruct_mesh_dc_quad(vertices: torch.Tensor, faces: torch.Tensor, resolution: int=256, band: float=1, verbose: bool=False, bvh=None, remove_inner_faces: bool=False, witness_roi=None):
    _ARC_SOURCE.clear()
    device = vertices.device
    chunk_size = 524288
    bbox_min = vertices.min(dim=0).values
    bbox_max = vertices.max(dim=0).values
    center = (bbox_min + bbox_max) * 0.5
    scale = (bbox_max - bbox_min).max().item() * 1.1
    if witness_roi is not None:
        if remove_inner_faces:raise ValueError('ROI witness never selects shells')
        center = torch.tensor(witness_roi['center'],dtype=torch.float32,device=device)
        scale = witness_roi['extent']
    edge_neighbor_voxel_offset = torch.tensor([[[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]], [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]], [[0, 0, 0], [0, 1, 0], [1, 1, 0], [1, 0, 0]]], dtype=torch.int32, device=device).unsqueeze(0)
    s1_n = torch.tensor([0, 1, 2, 0, 2, 3], device=device)
    s1_p = torch.tensor([0, 2, 1, 0, 3, 2], device=device)
    s2_n = torch.tensor([0, 1, 3, 3, 1, 2], device=device)
    s2_p = torch.tensor([0, 3, 1, 3, 2, 1], device=device)
    OFFSETS = torch.tensor([[0, 0, 0], [1, 0, 0], [0, 1, 0], [1, 1, 0], [0, 0, 1], [1, 0, 1], [0, 1, 1], [1, 1, 1]], dtype=torch.int32, device=device)

    def chunked_udf(bvh_ptr, pts):
        N = pts.shape[0]
        dist = torch.empty(N, dtype=torch.float32, device=device)
        for i in range(0, N, chunk_size):
            end = min(i + chunk_size, N)
            d, _, _ = bvh_ptr.unsigned_distance(pts[i:end])
            dist[i:end] = d
        return dist

    def chunked_sdf_raystab(bvh_ptr, pts):
        N = pts.shape[0]
        dist = torch.empty(N, dtype=torch.float32, device=device)
        for i in range(0, N, chunk_size):
            end = min(i + chunk_size, N)
            d, _, _ = bvh_ptr.signed_distance(pts[i:end], mode='raystab')
            dist[i:end] = d
        return dist
    if bvh is None:
        raise ValueError('An explicit unsigned-distance adapter is required')
    eps = max(band * scale / resolution, scale / resolution * 0.5)
    base_res = resolution
    while base_res > 32:
        base_res //= 2
    coords = torch.stack(torch.meshgrid(torch.arange(base_res, device=device), torch.arange(base_res, device=device), torch.arange(base_res, device=device), indexing='ij'), dim=-1).int().reshape(-1, 3)
    pbar = tqdm(total=int(torch.log2(torch.tensor(resolution // base_res)).item()) + 1, desc='Sparse Grid', disable=not verbose)
    while True:
        pbar.update(1)
        cell = scale / base_res
        pts = ((coords.float() + 0.5) / base_res - 0.5) * scale + center
        dist = chunked_udf(bvh, pts)
        coords = coords[torch.abs(dist - eps) < 0.87 * cell + eps * 0.5]
        if base_res >= resolution:
            break
        base_res *= 2
        coords = (coords.unsqueeze(1) * 2 + OFFSETS.unsqueeze(0)).reshape(-1, 3)
        coords = torch.unique(coords, dim=0)
    pbar.close()
    print('Dual Contouring ...')
    Nvox = coords.shape[0]
    hashmap_vox = _init_hashmap(resolution, 2 * Nvox, device)
    _C.hashmap_insert_3d_idx_as_val_cuda(*hashmap_vox, torch.cat([torch.zeros_like(coords[:, :1]), coords], dim=1), resolution, resolution, resolution)
    grid_verts = _C.get_sparse_voxel_grid_active_vertices(*hashmap_vox, coords.contiguous(), resolution, resolution, resolution)
    pts_vert = (grid_verts.float() / resolution - 0.5) * scale + center
    dist_vert = chunked_udf(bvh, pts_vert)
    hashmap_vert = _init_hashmap(resolution + 1, 2 * grid_verts.shape[0], device)
    _C.hashmap_insert_3d_idx_as_val_cuda(*hashmap_vert, torch.cat([torch.zeros_like(grid_verts[:, :1]), grid_verts], dim=1), resolution + 1, resolution + 1, resolution + 1)
    scalar = dist_vert - eps
    dual_slots, edge_slots, intersected, contour_counts, ambiguities = _C.contour_dual_contour(*hashmap_vert, coords.contiguous(), scalar.contiguous(), resolution + 1, resolution + 1, resolution + 1)
    if _CAPTURE_FIELDS:
        _TRACE.update(coords=coords.cpu().numpy(),grid_vertices=grid_verts.cpu().numpy(),scalar=scalar.cpu().numpy(),dual_slots=dual_slots.cpu().numpy(),edge_slots=edge_slots.cpu().numpy(),counts=contour_counts.cpu().numpy(),ambiguities=ambiguities.cpu().numpy(),center=center.cpu().numpy(),scale=scale,eps=eps,resolution=resolution)
    _METRICS.update(active_cells=int(coords.shape[0]),field_corner_entries=int(grid_verts.shape[0]),positive_cells=int((contour_counts>0).sum().item()),contour_vertices=int(contour_counts.sum().item()),multi_contour_cells=int((contour_counts>1).sum().item()),maximum_contours=int(contour_counts.max().item()),ambiguous_cell_faces=int(ambiguities.sum().item()),iso=float(eps))
    dual_verts = dual_slots.reshape(-1,3)
    print('Quad Topology ...')
    quad_list, dir_list = ([], [])
    owner_list = []
    skipped_outside = 0
    nz = torch.nonzero(intersected)
    for i in range(0, nz.shape[0], chunk_size):
        c = nz[i:i + chunk_size]
        v_idx, a_idx = (c[:, 0], c[:, 1])
        neigh = coords[v_idx].unsqueeze(1) + edge_neighbor_voxel_offset[0, a_idx]
        if witness_roi is not None:
            from dc_roi_witness import lookup_incident_cells
            lookup, keep = lookup_incident_cells(_C,hashmap_vox,coords,neigh,resolution)
            skipped_outside += int((~keep).sum().item())
            c, v_idx, a_idx, neigh, lookup = c[keep], v_idx[keep], a_idx[keep], neigh[keep], lookup[keep]
            if not len(c):continue
        else:
            keys = torch.cat([torch.zeros((neigh.shape[0] * 4, 1), dtype=torch.int32, device=device), neigh.reshape(-1, 3)], dim=1)
            lookup = _C.hashmap_lookup_3d_cuda(*hashmap_vox, keys, resolution, resolution, resolution).reshape(-1, 4).int()
            if not ((lookup >= 0) & (lookup < Nvox)).all().item():
                raise ValueError('A crossed primal edge lacks four valid sparse cells')
        primal_low = coords[v_idx].clone()
        for axis in range(3):
            primal_low[:,axis] += (a_idx != axis).to(torch.int32)
        relative = primal_low.unsqueeze(1) - coords[lookup.long()]
        edge_codes = torch.empty_like(lookup)
        for axis,other in enumerate(((1,2),(0,2),(0,1))):
            select = a_idx == axis
            if select.any():
                offsets = relative[select]
                if not ((offsets >= 0) & (offsets <= 1)).all().item() or not (offsets[:,:,axis] == 0).all().item():
                    raise ValueError('Invalid primal edge to incident-cell offset')
                edge_codes[select] = axis*4+2*offsets[:,:,other[0]]+offsets[:,:,other[1]]
        slots = edge_slots[lookup.long(),edge_codes.long()]
        if not ((slots >= 0) & (slots < contour_counts[lookup.long()])).all().item():
            raise ValueError('Primal edge contour slot contract failed')
        quad_list.append(lookup*4+slots)
        dir_list.append(intersected[v_idx,a_idx])
        if witness_roi is not None:owner_list.append(c)
    if not quad_list:
        return (torch.zeros((0, 3), device=device), torch.zeros((0, 3), device=device, dtype=torch.int32))
    quad_indices = torch.cat(quad_list, dim=0)
    intersected_dir = torch.cat(dir_list, dim=0).int()
    print('Re-indexing vertices ...')
    Nvox *= 4
    active = torch.zeros(Nvox, dtype=torch.bool, device=device)
    active[quad_indices.flatten()] = True
    vert_map = torch.full((Nvox,), -1, dtype=torch.int32, device=device)
    vert_map[active] = torch.arange(active.sum(), dtype=torch.int32, device=device)
    dual_verts = dual_verts[active]
    for i in range(0, quad_indices.shape[0], chunk_size):
        end = min(i + chunk_size, quad_indices.shape[0])
        quad_indices[i:end] = vert_map[quad_indices[i:end]]
    mesh_vertices = (dual_verts / resolution - 0.5) * scale + center
    if remove_inner_faces:
        print(f'Removing Inner Layer for {quad_indices.shape[0]} quads ...')
        quad_centers = torch.empty((quad_indices.shape[0], 3), dtype=torch.float32, device=device)
        for i in range(0, quad_indices.shape[0], chunk_size):
            end = min(i + chunk_size, quad_indices.shape[0])
            q = quad_indices[i:end].long()
            quad_centers[i:end] = (mesh_vertices[q[:, 0]] + mesh_vertices[q[:, 1]] + mesh_vertices[q[:, 2]] + mesh_vertices[q[:, 3]]) * 0.25
        sdf = chunked_sdf_raystab(bvh, quad_centers)
        is_outer = sdf >= -eps * 0.1
        quad_indices = quad_indices[is_outer]
        intersected_dir = intersected_dir[is_outer]
    print('Re-indexing vertices after quad filtering ...')
    used_verts = torch.zeros(mesh_vertices.shape[0], dtype=torch.bool, device=device)
    used_verts[quad_indices.flatten()] = True
    new_vert_idx = torch.full((mesh_vertices.shape[0],), -1, dtype=torch.int32, device=device)
    new_vert_idx[used_verts] = torch.arange(used_verts.sum(), dtype=torch.int32, device=device)
    mesh_vertices = mesh_vertices[used_verts]
    for i in range(0, quad_indices.shape[0], chunk_size):
        end = min(i + chunk_size, quad_indices.shape[0])
        quad_indices[i:end] = new_vert_idx[quad_indices[i:end]]
    print('Triangulation ...')
    mesh_triangles = torch.empty((quad_indices.shape[0] * 2, 3), dtype=torch.int32, device=device)
    for i in range(0, quad_indices.shape[0], chunk_size):
        end = min(i + chunk_size, quad_indices.shape[0])
        q = quad_indices[i:end]
        d = intersected_dir[i:end].unsqueeze(1)
        t1 = torch.where(d == 1, q[:, s1_p], q[:, s1_n])
        t2 = torch.where(d == 1, q[:, s2_p], q[:, s2_n])
        n1a = torch.linalg.cross(mesh_vertices[t1[:, 1]] - mesh_vertices[t1[:, 0]], mesh_vertices[t1[:, 2]] - mesh_vertices[t1[:, 0]])
        n1b = torch.linalg.cross(mesh_vertices[t1[:, 4]] - mesh_vertices[t1[:, 3]], mesh_vertices[t1[:, 5]] - mesh_vertices[t1[:, 3]])
        a1 = (n1a * n1b).sum(dim=1).abs()
        n2a = torch.linalg.cross(mesh_vertices[t2[:, 1]] - mesh_vertices[t2[:, 0]], mesh_vertices[t2[:, 2]] - mesh_vertices[t2[:, 0]])
        n2b = torch.linalg.cross(mesh_vertices[t2[:, 4]] - mesh_vertices[t2[:, 3]], mesh_vertices[t2[:, 5]] - mesh_vertices[t2[:, 3]])
        a2 = (n2a * n2b).sum(dim=1).abs()
        mesh_triangles[i * 2:end * 2] = torch.where((a1 < a2).unsqueeze(1), t1, t2).reshape(-1, 3)
    if witness_roi is None:
        if int(mesh_vertices.shape[0]) != _METRICS['contour_vertices']:
            raise ValueError('Positive native contours were not all referenced; no silent discard')
    else:
        positive = (torch.arange(4,device=device)[None,:] < contour_counts[:,None]).reshape(-1)
        unused = torch.nonzero(positive & ~active).flatten()
        unused_cells = coords[unused//4]
        if len(unused) and not ((unused_cells == 0) | (unused_cells == resolution-1)).any(dim=1).all().item():
            raise ValueError('An interior native contour was not referenced by the ROI witness')
        nz = torch.cat(owner_list,dim=0)
        _METRICS.update(witness_only=True,skipped_outside_crossings=skipped_outside,
            unreferenced_boundary_contours=int(len(unused)),referenced_contours=int(mesh_vertices.shape[0]),
            voxel=scale/resolution,field_iso_f32=float(torch.tensor(eps,dtype=torch.float32).item()),roi_center=center.cpu().tolist(),roi_extent=scale)
    # Keep only references until driver admission. Successful stock meshes do
    # not transfer these buffers; the controller requests them only on refusal.
    _ARC_SOURCE.update(coords=coords,grid_vertices=grid_verts,scalar=scalar,edge_slots=edge_slots,counts=contour_counts,
        active=active,used=used_verts,quads=quad_indices,owners=nz,center=center,scale=scale,resolution=resolution,retain_all=not remove_inner_faces)
    return (mesh_vertices, mesh_triangles)
