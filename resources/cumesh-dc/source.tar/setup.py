from setuptools import setup
from torch.utils.cpp_extension import CUDAExtension, BuildExtension
from pathlib import Path
import os
setup(name='cumesh-dc-isolated-proof', version='0.0.0', packages=[],
 ext_modules=[CUDAExtension('_h3_dc_contours', sources=['bindings.cpp','src/hash/hash.cu','src/remesh/svox2vert.cu','src/remesh/contour_dual.cu'],
 include_dirs=[str(Path(os.environ['CUDA_HOME'])/'include/cccl')],
 extra_compile_args={'cxx':['-O3','-std=c++20'], 'nvcc':['-O3','-std=c++20','-allow-unsupported-compiler','--threads=1']})],
 cmdclass={'build_ext':BuildExtension})
