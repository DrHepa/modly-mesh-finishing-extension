from collections import defaultdict
import numpy as np

def topology(v,f):
    assert v.dtype==np.float32 and f.dtype==np.int32 and v.ndim==f.ndim==2 and v.shape[1]==f.shape[1]==3 and len(v)>0 and len(f)>0
    assert np.isfinite(v).all() and f.min()>=0 and f.max()<len(v)
    tri=v[f].astype(float);area=np.linalg.norm(np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]),axis=1)
    edge=np.concatenate((f[:,[0,1]],f[:,[1,2]],f[:,[2,0]]));unique,inv,c=np.unique(np.sort(edge,axis=1),axis=0,return_inverse=True,return_counts=True);balance=np.bincount(inv,weights=np.where(edge[:,0]<edge[:,1],1,-1));parent=np.arange(len(v))
    def find(i):
        while parent[i]!=i:parent[i]=parent[parent[i]];i=int(parent[i])
        return i
    for a,b in unique:
        a=find(int(a));b=find(int(b));parent[b]=a
    links=[defaultdict(list) for _ in v]
    for tr in f:
        for i in range(3):
            center,a,b=map(int,(tr[i],tr[(i+1)%3],tr[(i+2)%3]));links[center][a].append(b);links[center][b].append(a)
    bad=0
    for graph in links:
        if not graph:bad+=1;continue
        seen=set();stack=[next(iter(graph))]
        while stack:
            i=stack.pop()
            if i in seen:continue
            seen.add(i);stack.extend(set(graph[i])-seen)
        bad+=int(len(seen)!=len(graph) or any(len(x)!=2 for x in graph.values()))
    return dict(vertices=len(v),triangles=len(f),components=len({find(int(i))for i in np.unique(f)}),Euler=len(v)-len(unique)+len(f),boundary_edges=int((c==1).sum()),nonmanifold_edges=int((c>2).sum()),orientation_conflicts=int(((c==2)&(balance!=0)).sum()),duplicate_faces=len(f)-len(np.unique(np.sort(f,axis=1),axis=0)),nonpositive_area=int((area<=0).sum()),bad_vertex_links=bad)

def field(trace):
    g,s=trace['grid_vertices'],trace['scalar'];u,inv=np.unique(g,axis=0,return_inverse=True);lo=np.full(len(u),np.iinfo(np.uint32).max,np.uint32);hi=np.zeros(len(u),np.uint32);bits=s.view(np.uint32);np.minimum.at(lo,inv,bits);np.maximum.at(hi,inv,bits);assert np.array_equal(lo,hi) and np.isfinite(s).all()
    return {tuple(map(int,p)):float(x)for p,x in zip(g,s)},u,lo

def orientation(v,f,trace):
    values,_,_=field(trace);tri=v[f].astype(float);centers=tri.mean(1);q=((centers-trace['center'])/float(trace['scale'])+.5)*int(trace['resolution']);normals=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);minimum=1.;bad=0
    for p,n in zip(q,normals):
        low=np.floor(p).astype(int);t=p-low;a=np.array([[[values[tuple(low+[i,j,k])]for k in range(2)]for j in range(2)]for i in range(2)]);w=[np.array([1-x,x])for x in t]
        grad=np.array([sum((a[1,j,k]-a[0,j,k])*w[1][j]*w[2][k]for j in range(2)for k in range(2)),sum((a[i,1,k]-a[i,0,k])*w[0][i]*w[2][k]for i in range(2)for k in range(2)),sum((a[i,j,1]-a[i,j,0])*w[0][i]*w[1][j]for i in range(2)for j in range(2))]);den=np.linalg.norm(n)*np.linalg.norm(grad);assert den>0;cos=float(n@grad/den);minimum=min(minimum,cos);bad+=int(cos<=0)
    return dict(nonpositive_gradient_orientation=bad,minimum_cosine=minimum,scope='Numerical F64 actual trilinear-field gradient at triangle centroids; not global selfintersection or exact UDF visibility')
