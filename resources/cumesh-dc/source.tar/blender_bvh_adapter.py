"""Reusable sparse distance provider: CPU Blender BVH, not GPU nearest distance."""
import hashlib,json,os,selectors,subprocess,time,zipfile
from pathlib import Path
import numpy as np
import torch

class BlenderBVHAdapter:
    maximum_faces=2_000_000
    def __init__(self,vertices,faces,*,directory,deadline,blender,cpu_threads=8):
        if (not vertices.is_cuda or not faces.is_cuda or vertices.device!=faces.device or vertices.dtype!=torch.float32 or faces.dtype!=torch.int32
                or vertices.ndim!=2 or faces.ndim!=2 or vertices.shape[1]!=3 or faces.shape[1]!=3 or not 0<len(vertices)<=2_000_000 or not 0<len(faces)<=self.maximum_faces
                or not torch.isfinite(vertices).all().item()or faces.min().item()<0 or faces.max().item()>=len(vertices)):raise ValueError('Invalid arbitrary-triangle BVH source')
        self.device=vertices.device;self.vertices=vertices.detach().clone();self.faces=faces.detach().clone();self.root=Path(directory);self.root.mkdir();assert self.root.resolve()==self.root
        self.deadline=deadline;self.ordinal=0;self.aggregate=0;self.calls=[];self.facts=[];self.buffer=b'';self.process=None
        bundle=Path(__file__).resolve().parent;self.sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();spec=json.loads((bundle/'runtime-spec.json').read_text());blender=Path(blender)
        if not blender.is_absolute()or not blender.is_file()or self.sha(blender)!=spec['blender_sha256']or self.sha(bundle/'blender_bvh_worker.py')!=spec['worker_sha256']:raise RuntimeError('Fixed owned BVH worker/qualified Blender identity changed')
        if type(cpu_threads)is not int or not 1<=cpu_threads<=8:raise ValueError('CPU thread admission must be1..8')
        source=self.root/'source.npz'
        with source.open('xb')as stream:np.savez(stream,vertices=np.ascontiguousarray(vertices.cpu().numpy()),faces=np.ascontiguousarray(faces.cpu().numpy()))
        env={k:v for k,v in os.environ.items()if not k.startswith(('PYTHON','LD_','PIP_','BLENDER_'))}
        for key,name in [('HOME','home'),('TMPDIR','tmp'),('XDG_CACHE_HOME','cache'),('XDG_CONFIG_HOME','config')]:p=self.root/name;p.mkdir();env[key]=str(p)
        env.update(PATH='/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',OMP_NUM_THREADS=str(cpu_threads),OPENBLAS_NUM_THREADS='1')
        seconds=min(180.,deadline-time.monotonic())
        if seconds<1:raise TimeoutError('BVH rebuild deadline already exceeded')
        self.stderr=(self.root/'stderr.log').open('xb');self.stdout=(self.root/'stdout.log').open('xb')
        argv=[str(blender),'--background','--factory-startup','--disable-autoexec','-noaudio','--threads',str(cpu_threads),'--python-exit-code','1','--python',str(bundle/'blender_bvh_worker.py'),'--','--directory',str(self.root),'--parent-pid',str(os.getpid()),'--seconds',str(seconds)]
        try:
            self.process=subprocess.Popen(argv,cwd=self.root,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.stderr,bufsize=0)
            (self.root/'invocation.json').write_text(json.dumps(dict(argv=argv,pid=self.process.pid,pgid=os.getpgrp(),parent_pid=os.getpid(),source_sha256=self.sha(source)),indent=2)+'\n')
            ready=self._reply()
            if ready.get('status')!='READY'or ready.get('source_sha256')!=self.sha(source)or ready.get('source_faces')!=len(faces)or ready.get('source_vertices')!=len(vertices)or ready.get('scene_objects')!=0:raise RuntimeError('BVH readiness/source contract failed: '+str(ready))
            self.ready=ready
        except BaseException:self.close(abort=True);raise
    def _reply(self):
        selector=selectors.DefaultSelector();selector.register(self.process.stdout,selectors.EVENT_READ)
        try:
            while True:
                while b'\n'in self.buffer:
                    line,self.buffer=self.buffer.split(b'\n',1)
                    if line.startswith(b'BVH_REPLY '):
                        if len(line)>16384:raise ValueError('BVH reply exceeds framing limit')
                        return json.loads(line[10:])
                remaining=self.deadline-time.monotonic()
                if remaining<=0:raise TimeoutError('BVH response deadline')
                if not selector.select(min(remaining,1)):continue
                block=os.read(self.process.stdout.fileno(),65536)
                if not block:raise RuntimeError('BVH worker exited before reply; see '+str(self.root/'stderr.log'))
                self.stdout.write(block);self.stdout.flush();self.buffer+=block
                if len(self.buffer)>2*1024**2:raise ValueError('BVH startup/output framing exceeded')
        finally:selector.close()
    def query(self,points,*,purpose='verification'):
        if (points.device!=self.device or points.dtype!=torch.float32 or points.ndim!=2 or points.shape[1]!=3 or not 0<len(points)<=524288 or not torch.isfinite(points).all().item()):raise ValueError('Invalid BVH typed query')
        if self.ordinal>=32 or self.aggregate+len(points)>4_000_000 or time.monotonic()>=self.deadline:raise ValueError('BVH batch/aggregate/deadline admission exceeded')
        path=self.root/f'query-{self.ordinal:03d}.npz'
        with path.open('xb')as stream:np.savez(stream,queries=np.ascontiguousarray(points.cpu().numpy()))
        command=dict(operation='query',ordinal=self.ordinal,rows=len(points),sha256=self.sha(path));self.process.stdin.write((json.dumps(command)+'\n').encode());self.process.stdin.flush();fact=self._reply()
        output=self.root/f'answer-{self.ordinal:03d}.npz'
        if fact.get('status')!='QUERY_COMPLETE'or fact.get('ordinal')!=self.ordinal or fact.get('rows')!=len(points)or fact.get('input_sha256')!=command['sha256']or fact.get('output_sha256')!=self.sha(output):raise RuntimeError('BVH reply/input/output identity failed: '+str(fact))
        if output.is_symlink()or output.stat().st_size>16*1024**2:raise ValueError('BVH response file admission exceeded')
        expected={'distances':((len(points),),np.dtype(np.float32)),'nearest':((len(points),3),np.dtype(np.float32)),'triangle_ids':((len(points),),np.dtype(np.int32))}
        with zipfile.ZipFile(output)as archive:
            if set(archive.namelist())!={k+'.npy'for k in expected}or any(x.compress_type!=zipfile.ZIP_STORED for x in archive.infolist()):raise ValueError('BVH response layout rejected')
            for key,(shape,dtype)in expected.items():
                with archive.open(key+'.npy')as stream:
                    if np.lib.format.read_magic(stream)!=(1,0):raise ValueError('Unsupported BVH response NPY version')
                    actual,fortran,kind=np.lib.format.read_array_header_1_0(stream)
                    if actual!=shape or kind!=dtype or fortran:raise ValueError('BVH response header rejected before allocation')
        with np.load(output,allow_pickle=False)as z:d,q,i=(z[k]for k in ('distances','nearest','triangle_ids'))
        if d.dtype!=np.float32 or q.dtype!=np.float32 or i.dtype!=np.int32 or d.shape!=(len(points),)or q.shape!=(len(points),3)or i.shape!=d.shape or not np.isfinite(d).all()or not np.isfinite(q).all()or (d<0).any()or i.min()<0 or i.max()>=len(self.faces):raise RuntimeError('BVH invalid typed response; no fallback')
        self.ordinal+=1;self.aggregate+=len(points);self.facts.append(dict(purpose=purpose,**fact))
        return torch.from_numpy(d.copy()).to(self.device),torch.from_numpy(i.copy()).to(self.device),torch.from_numpy(q.copy()).to(self.device)
    def unsigned_distance(self,points,return_uvw=False):
        self.calls.append(len(points));d,i,q=self.query(points,purpose='reconstruction');bary=None
        if return_uvw:
            t=self.vertices[self.faces[i.long()].long()].double();u=t[:,1]-t[:,0];v=t[:,2]-t[:,0];r=q.double()-t[:,0];uu=(u*u).sum(1);vv=(v*v).sum(1);uv=(u*v).sum(1);du=(r*u).sum(1);dv=(r*v).sum(1);den=uu*vv-uv*uv
            if not (den>0).all().item():raise ValueError('BVH triangle barycentric Gram unresolved')
            a=(du*vv-dv*uv)/den;b=(dv*uu-du*uv)/den;bary=torch.stack((1-a-b,a,b),1).float()
        return d,i,bary
    def signed_distance(self,*args,**kwargs):raise ValueError('CPU BVH signed distance is not qualified')
    def close(self,*,abort=False):
        if self.process is not None:
            try:
                if not abort and self.process.poll()is None:
                    self.process.stdin.write(b'{"operation":"close"}\n');self.process.stdin.flush();fact=self._reply()
                    if fact.get('status')!='CLOSED':raise RuntimeError('BVH clean close protocol failed')
                if abort and self.process.poll()is None:self.process.terminate()
                self.process.wait(timeout=max(.1,min(5,self.deadline-time.monotonic())))
                if not abort and self.process.returncode:raise RuntimeError('BVH worker natural exit failed')
            except BaseException:
                if self.process.poll()is None:self.process.kill();self.process.wait(timeout=5)
                raise
            finally:
                self.process.stdin.close();self.process.stdout.close();self.stderr.close();self.stdout.close();self.process=None
