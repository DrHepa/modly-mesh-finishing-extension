# SPDX-License-Identifier: GPL-3.0-or-later
"""Read the actual fixed tiny runtime smoke; never generate or repair geometry."""
import hashlib,json,sys
from pathlib import Path
import numpy as np
root=Path(sys.argv[1]).resolve();sys.path.insert(0,str(root/'source'))
import cpu_checks
metrics=json.loads((root/'smoke-metrics.json').read_text())
if metrics['status']!='geometry_proposal'or metrics['resolution']!=32 or metrics['policy']!='retain_all_unsigned_shells':raise RuntimeError('Actual DC smoke did not complete the fixed reconstruction')
with np.load(root/'dc-field.npz',allow_pickle=False)as data:trace={key:data[key]for key in data.files}
v,f=trace['vertices'],trace['faces'];indexed=cpu_checks.topology(v,f);positions,inverse=np.unique(v,axis=0,return_inverse=True);physical=cpu_checks.topology(positions,inverse.astype(np.int32)[f]);orientation=cpu_checks.orientation(v,f,trace)
for facts in (indexed,physical):
    if any(facts[k]for k in ('boundary_edges','nonmanifold_edges','orientation_conflicts','duplicate_faces','nonpositive_area','bad_vertex_links')):raise RuntimeError('DC smoke failed independent complete numeric topology')
if len(positions)!=len(v)or indexed['components']!=1 or orientation['nonpositive_gradient_orientation']or metrics['native']['multi_contour_cells']<1 or metrics['native']['contour_vertices']!=len(v):raise RuntimeError('DC smoke did not exercise genuine manifold contour separation')
blob=(root/'smoke.ply').read_bytes();header,payload=blob.split(b'end_header\n',1);lines=header.decode('ascii').splitlines();nv=int(next(x for x in lines if x.startswith('element vertex ')).split()[-1]);nf=int(next(x for x in lines if x.startswith('element face ')).split()[-1])
pv=np.frombuffer(payload[:nv*12],dtype='<f4').reshape(nv,3);rows=np.frombuffer(payload[nv*12:],dtype=[('count','u1'),('indices','<i4',(3,))])
if nv!=len(v)or nf!=len(f)or not np.all(rows['count']==3)or pv.tobytes()!=v.tobytes()or rows['indices'].tobytes()!=f.tobytes():raise RuntimeError('Actual PLY serialization changed native geometry')
worker=metrics['worker_result']
if worker['status']!='CLOSED'or worker['source_faces']!=10 or worker['source_vertices']!=8 or worker['scene_objects']!=0 or len(worker['batches'])!=2 or any(x['missing']or x['filled']for x in worker['batches']):raise RuntimeError('CPU BVH runtime smoke contract failed')
proof=dict(scope='One fixed real open-mesh native CUDA contour/CPU Blender BVH smoke, not product node/general quality',
           vertices=int(len(v)),triangles=int(len(f)),components=indexed['components'],Euler=indexed['Euler'],indexed=indexed,physical=physical,
           orientation=orientation,native=metrics['native'],cpu_blender=worker['blender'],cpu_python=worker['python'],distance_batches=[int(x['rows'])for x in worker['batches']],
           cpu_query_seconds=float(sum(x['cpu_query_seconds']for x in worker['batches'])),output_sha256=hashlib.sha256(blob).hexdigest(),self_intersections='NOT_EVALUATED')
(root/'smoke-proof.json').write_text(json.dumps(proof,indent=2,allow_nan=False)+'\n');print(json.dumps(proof),flush=True)
