"""Core-only CuMesh profile: BVH, remeshing and DC are intentionally absent."""
from .cumesh import CuMesh
from .xatlas import Atlas

__all__ = ["CuMesh", "Atlas"]
CORE_ONLY = True
